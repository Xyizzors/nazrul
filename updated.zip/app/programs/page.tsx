import type { Metadata } from "next";
import { bilingual, innerHero, photo } from "@/components/ui";
import data_programs from "@/data/programs.json";
import { textMap } from "@/lib/content";
import ExtraImages from "@/components/ExtraImages";

export function generateMetadata(): Metadata {
  const { title, description } = data_programs.meta[0];
  return { title, description };
}

const txt = textMap(data_programs.texts);

export default function ProgramsPage() {
  const programs = data_programs.programs;

  return (
    <>
      <ExtraImages items={data_programs.extras} after={0} />
      {innerHero({
        eyebrow_en: txt.t9.en,
        eyebrow_bn: txt.t9.bn,
        title_en: txt.t10.en,
        title_bn: txt.t10.bn,
        desc_en: txt.t11.en,
        desc_bn: txt.t11.bn,
      })}
      <ExtraImages items={data_programs.extras} after={1} />

      <section className="section-pad">
        <div className="wrap grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {programs.map((p, __i) => (
            <div key={__i} className="card overflow-hidden flex flex-col">
              {photo({ src: p.photo }, p.en + " — placeholder", "aspect-[4/3]")}
              <div className="p-5 flex flex-col gap-2 flex-1">
                <h3 className="font-display text-lg text-green-900 leading-snug">
                  <span className="lang-en">{p.en}</span>
                  <span className="lang-bn">{p.bn}</span>
                </h3>
                <p className="text-xs text-charcoal-500">
                  <span className="lang-en">{p.sched_en}</span>
                  <span className="lang-bn">{p.sched_bn}</span>
                </p>
                <p className="text-sm text-charcoal-700 leading-relaxed flex-1">
                  <span className="lang-en">{p.desc_en}</span>
                  <span className="lang-bn">{p.desc_bn}</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
      <ExtraImages items={data_programs.extras} after={2} />
    </>
  );
}
